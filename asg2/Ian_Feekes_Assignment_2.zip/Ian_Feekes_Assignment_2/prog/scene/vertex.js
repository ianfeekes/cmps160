/**
 * Specifies a vertex. Currently only contains the vertex's position.
 *
 * @author "Your Name Here"
 * @this {Vertex}
 */
class Vertex {
  constructor() {
    this.points = [];
  }
}
