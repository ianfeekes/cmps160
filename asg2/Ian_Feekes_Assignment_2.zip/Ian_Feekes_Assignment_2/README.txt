Welcome to CMPS 160's assignment 2!

This zip file contains the necessary starter code and structure for this
assignment. Note that while the provided structure is mandatory, expanding upon the
structure is HIGHLY encouraged.

Good luck!
-----------------------------------------------------------------------------------
Ian Feekes
ifeekes@ucsc.edu
#1474914
asg2

The purpose of this assignment was to create a canvas with displays and interactions 
very similar to asg1, with several modifications expanded upon. The functionality differs
in that the user has the option of selecting a shape (square, triangle, sphere) that the
canvas draws rather than solely allowing for the drawing of points
This assignment was completed without a partner. 
The directory for this assignment should contain the following files that have had
significant work done: 
-driver.html             (initializes scripts and html text values) 
-eventFunctions.js       (handles all possible user interaction events)
-glslFunctions.js        (handles functions forvalues being passed to and from the shaders)
-htmlFunctions.js        (contains sendTextToHTML function for text box mouse coord use) 
-shaders.js              (initializes the vertex and colour shaders for use of program) 
